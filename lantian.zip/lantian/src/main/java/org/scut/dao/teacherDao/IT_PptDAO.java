package org.scut.dao.teacherDao;

import java.util.*;
public interface IT_PptDAO {
	public ArrayList<Integer> getPptList(String teacher_id);
}

package org.scut.dao.teacherDao;

import java.util.ArrayList;

public interface IT_CollectionDAO {
	public ArrayList<Integer> getCollectionList(String teacher_id);
}

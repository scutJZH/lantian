package org.scut.service;

import org.scut.model.User;

public interface IUserService {
    public User selectUser(long userId);
}

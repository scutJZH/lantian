package org.scut.service.publicService;

public interface IVerificateService {

	public boolean verificateTelnumber(String telnumber, String type);

}

package org.scut.service.teacherService;
import java.util.*;
import org.scut.model.*;
public interface IT_Optional_Exercise_Service {
	public ArrayList<T_Optional_ExerciseVO> get_Optional_Exercise(HashMap<String,Integer> optional_subject);
}

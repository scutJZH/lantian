package org.scut.service.teacherService;

import java.util.*;
import org.scut.model.*;
public interface IT_Selected_Exercise_Service {
	public boolean insert(ArrayList<T_Selected_ExerciseVO> t_Selected_ExerciseVO);
}

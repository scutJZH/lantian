package org.scut.service.teacherService;

import java.util.ArrayList;

public interface IT_Collection_Service {
	public ArrayList<Integer> getCollectionList(String teacher_id);
}

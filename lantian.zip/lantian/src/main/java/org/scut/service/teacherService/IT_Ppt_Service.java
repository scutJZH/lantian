package org.scut.service.teacherService;

import java.util.ArrayList;

public interface IT_Ppt_Service {
	
	public ArrayList<Integer> getPptList(String teacher_id);
}

package org.scut.service.teacherService;

import java.util.*;
import org.scut.model.*;
public interface IT_Optional_Subject_Service {
	public ArrayList<T_Optional_SubjectVO> get_Optional_Subject(String teacher_id);

}

package org.scut.model;

public class T_Optional_ExerciseVO {
private int optional_exercise;
private int optional_subject;

//get
public int getOptional_exercise() {
	return optional_exercise;
}
public int getOptional_subject() {
	return optional_subject;
}
//set
public void setOptional_exercise(int optional_exercise) {
	this.optional_exercise=optional_exercise;
}
public void setOptional_subject(int optional_subject) {
	this.optional_subject=optional_subject;
}
}
